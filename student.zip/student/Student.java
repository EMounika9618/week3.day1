package student;
import department.Department;

public class Student extends Department{
	public void studentName() {
		System.out.println("Student Name: Mounika");
	}
	public void studentDept() {
		System.out.println("Student Department: ECE");
	}
	public void studentId() {
		System.out.println("Student ID: 439292");
	}
	public static void main(String arg[]) {
		Student st = new Student();
		
		// College Class methods
		st.collegeCode();
		st.collegeName();
		st.collegeRank();
		
		//Department Class methods
		st.deptName();
		
		//Student Class methods
		st.studentId();
		st.studentName();
		st.studentDept();
	}
}
