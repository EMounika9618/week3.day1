package college;

public class College {

	public void collegeName() {
		System.out.println("College Name: KITS");
	}
	public void collegeCode() {
		System.out.println("College Code: 439292");
	}
	public void collegeRank() {
		System.out.println("College Grade : 9.2");
	}
}
