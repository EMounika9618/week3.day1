package department;
import college.College;

public class Department  extends College
{
	public void deptName() {
		System.out.println("Department Name: ECE");
	}


}
