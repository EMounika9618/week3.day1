package system;

public class Computer {

	public void computerModel() {
		System.out.println("HP");
	}
}
